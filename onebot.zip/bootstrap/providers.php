<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\MacroServiceProvider::class,
    App\Providers\RepositoryProvider::class,
];
