##OneBot Project

###Converstion format

```
[
    {
        "id": "",
        "app_type": "",
        "date": "",
        "time": "",
        "conv_type": "",
        "sender": {
            "id": "",
            "name": "",
            "type": "",
        },
        "attached": [
            {
                "name": "",
                "type": "",
                "size": "",
                "path": "",
                "description": "",
                "caption": ""
            }
        ],
        "message": "",
        "status": ""
    }
]
```
