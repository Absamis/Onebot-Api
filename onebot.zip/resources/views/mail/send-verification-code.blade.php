<html lang="en">
<head>
</head>
<body>
    <h4>Hy {{$user->name}},</h4>
    <p>Your account verification code is {{$data->plainCode}}</p>
</body>
</html>
