<?php

namespace App\Enums;

class WhatsAppScopesEnums
{
    const businessManagement = 'business_management';
    const whatsappBusinessManagement = 'whatsapp_business_management';
    const whatsappBusinessMessaging = 'whatsapp_business_messaging';
}
