<?php

namespace App\Enums;

enum RoleEnums
{
    //
    const ownerRole = "owner";
    const adminRole = "admin";
}
