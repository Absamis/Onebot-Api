<?php

namespace App\Enums;

enum GoogleScopesEnums
{
    //
    const loginScope = "https://www.googleapis.com/auth/userinfo.email+https://www.googleapis.com/auth/userinfo.profile+openid";
}
