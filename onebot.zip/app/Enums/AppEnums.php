<?php

namespace App\Enums;

enum AppEnums
{
    //
    const active = 1;
    const inactive = 0;
}
