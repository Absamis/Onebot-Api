<?php

namespace App\Services\Socials;

class TelegramService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
}
