<?php

namespace App\Http\Controllers\Channels;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TelegramChannelController extends Controller
{
    //

    public function webhook(Request $request)
    {
        Storage::put("teleg", json_encode($request->all()));
    }
}
