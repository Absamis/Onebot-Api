<?php

namespace App\Models\Configurations;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountOption extends Model
{
    use HasFactory;

    protected $table = 'account_options';

    protected $fillable = [];
}
